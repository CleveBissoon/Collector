//dictionaries

var dogInfo : [String:Int] = ["Fido":5,"Sean":19,"Sara":43]

dogInfo["Fido"]

dogInfo["John"] = 77

dogInfo

// make dictionary with double for keys and bools for values

var challenge = [34.5:true,1.1:false,98.532:true,213.1:true]

challenge
